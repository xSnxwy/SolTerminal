# Solterminal – Wallet Simulation für Spck Editor

Dies ist eine eigenständige, offline nutzbare Wallet-Simulation. Sie braucht weder den ursprünglichen Next.js-Server noch API-Schlüssel oder eine echte Solana-Wallet-Erweiterung.

## In Spck Editor starten

1. Lade `Solterminal-Wallet-Simulation.zip` herunter und entpacke sie.
2. Öffne Spck Editor und wähle **Open Project / Projekt öffnen**.
3. Öffne den Ordner `solterminal-wallet-sim`.
4. Öffne `index.html` und starte **Preview / Vorschau**.
5. Das Demo-Wallet ist direkt angelegt. Die Startbestände sind **5 SOL und 10.000 USDC**.

## Enthaltene Funktionen

- Dashboard mit Gesamtvermögen, 24h-Veränderung und Portfolio
- Simulierte Token-Märkte mit Suche, Kursen, Marktkapitalisierung und Risiko-Indikator
- Watchlist mit bis zu 10 Assets
- Simulierter Kurs-Chart und manuelle Marktbewegungen
- Kaufen, Verkaufen und Token-Swaps zwischen SOL, USDC, BTC, ETH, JUP, RAY, BONK, WIF, PYTH und JTO
- Slippage-Einstellung, simulierte Handelsgebühr und Priority Fee
- Wallet-Ansicht mit Demo-Adresse
- Simuliertes Senden und Empfangen / Demo-Guthaben hinzufügen
- Transaktionsverlauf mit Filtern und CSV-Export
- Wallet-Name, Gebühreneinstellungen, JSON-Backup und Wiederherstellung
- Automatische lokale Speicherung nach Aktionen

## Speichern – wichtig

Der Spielstand wird automatisch im lokalen Browser-/WebView-Speicher (`localStorage`) abgelegt. Er bleibt normalerweise erhalten, wenn du dieselbe Spck-Vorschau erneut öffnest. Das Löschen der App-Daten, Website-Daten oder des WebView-Speichers kann den Spielstand entfernen.

**Sichere deinen Spielstand regelmäßig:** Einstellungen → **Backup herunterladen**. Die JSON-Datei kannst du später über **Backup importieren** wiederherstellen. CSV-Export im Transaktionsbereich sichert zusätzlich den Verlauf lesbar.

## Was diese Simulation ausdrücklich nicht macht

- Sie verbindet sich nicht mit Solana Mainnet oder Devnet.
- Sie hält keine echten Token und verwendet keine privaten Schlüssel oder Seed-Phrases.
- Kaufen, Verkaufen, Swaps, Senden und Empfangen ändern ausschließlich den lokalen Demo-Spielstand.
- Preise, Marktbewegungen, Liquidität, Marktkapitalisierung und Risiko-Scores sind Beispieldaten und keine Live-Marktdaten oder Sicherheitsprüfungen.
- Die angezeigte Demo-Adresse ist keine echte Solana-Adresse.

Die Simulation ist zum Ausprobieren der Terminal-Funktionen gedacht und nicht für echte Investments oder Transaktionen.
